<!-- sidebar menu -->
            <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
                <h3>MENÜLER</h3>




                <ul class="nav side-menu">
                  <li><a href="index.php"><i class="fa fa-home"></i>Anasayfa</a></li>     
                </ul>

               

               <ul class="nav side-menu">
                  <li><a><i class="fa fa-image"></i>Resim Galerisi<span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                    <li><a href="resimgalerisi.php"><i ></i>Resimler</a></li>
                    <li><a href="resim-ekle.php"><i></i>Resim Ekle</a></li> 
                    </ul>
                  </li>   
                </ul>


                 <ul class="nav side-menu">
                  <li><a><i class="fa fa-mobile"></i>Video Galerisi<span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                    <li><a href="videogalerisi.php"><i ></i>Videolar</a></li>
                    <li><a href="video-ekle.php"><i></i>Video Ekle</a></li> 
                    </ul>
                  </li>   
                </ul>

                <ul class="nav side-menu">
                  <li><a><i class="fa fa-laptop"></i>Sevis Sayfası İşlemleri <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                    <li><a href="servisler.php"><i ></i>Sevis</a></li>
                    <li><a href="servisler-ekle.php"><i ></i>Sevis Ekle</a></li> 
                    </ul>
                  </li>   
                </ul>


                <ul class="nav side-menu">
                  <li><a><i class="fa fa-image"></i>Slider İşlemleri <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                    <li><a href="slider-duzenle.php"><i ></i>Slider</a></li>
                    <li><a href="slider-ekle.php"><i ></i>Slider Ekle</a></li> 
                    </ul>
                  </li>   
                </ul>
                  <ul class="nav side-menu">
                  <li><a><i class="fa fa-shopping-cart"></i>Hizmetler <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                    <li><a href="hizmetler.php"><i ></i>Hizmetler</a></li>
                    <li><a href="hizmet-ekle.php"><i ></i>Hizmet Ekle</a></li> 
                    </ul>
                  </li>   
                </ul>
                <ul class="nav side-menu">
                  <li><a><i class="fa fa-file-text"></i>Blog Haber <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                    <li><a href="icerik.php"><i ></i>Haber Düzenle</a></li>
                    <li><a href="icerik-ekle.php"><i ></i>Haber Ekle</a></li> 
                    </ul>
                  </li>   
                </ul>


                <ul class="nav side-menu">
                  <li><a><i class="fa fa-cog"></i> Ayarlar <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="genel-ayar.php">Genel Ayarlar</a></li>
                      <li><a href="sosyal-ayar.php">Sosyal Media Ayarları</a></li>
                      <li><a href="iletisim-ayar.php">İletişim Ayarları</a></li>
                      <li><a href="api-ayar.php">Api Ayarları</a></li>
                      <li><a href="mail-ayar.php">Mail Ayarları</a></li>
                    </ul>
                  </li>      
                </ul>

                <ul class="nav side-menu">
                  <li><a href="logo-guncelle.php"><i class="fa fa-fire"></i>Logo</a></li>     
                </ul>

                 <ul class="nav side-menu">
                  <li><a href="hakkimizda.php"><i class="fa fa-book"></i>Hakkımızda</a></li>     
                </ul>



                 <ul class="nav side-menu">
                  <li><a href="videocekme.php"><i class="fa fa-youtube"></i>Video</a></li>     
                </ul>



                <ul class="nav side-menu">
                     <li><a href="twit.php"><i class="fa fa-twitter"></i>Twit At</a></li>   
                </ul>

              </div>
              <div class="menu_section">
                <h3>Live On</h3>
                <ul class="nav side-menu">
                
                 
                                  
                  <li><a href="javascript:void(0)"><i class="fa fa-laptop"></i> Landing Page <span class="label label-success pull-right">Coming Soon</span></a></li>
                </ul>
              </div>

            </div>
            <!-- /sidebar menu -->