<section id="mu-testimonials">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="mu-testimonials-area">
							<h2>KİM NE SÖYLEMİŞ</h2>

							<div class="mu-testimonials-block">
								<ul class="mu-testimonial-slide">

									<li>
										<img class="mu-rt-img" src="assets/images/traveler-2.jpg" alt="img">
										<p>Harika işler başarmak için harika adımlar atmak gerekir</p>
										<h5 class="mu-rt-name">Mehmet Ürgün</h5>
										<span class="mu-rt-title">Web Developer </span>
									</li>

									<li>
										<img class="mu-rt-img" src="assets/images/traveler-2.jpg" alt="img">
										<p>Tasarım bir hayat tasarladıgın gibi yaşarsın</p>
										<h5 class="mu-rt-name">Mehmet Ürgün</h5>
										<span class="mu-rt-title">UI/UX Designer</span>
									</li>

									<li>
										<img class="mu-rt-img" src="assets/images/traveler-2.jpg" alt="img">
										<p>Tasarım bir hayat tasarladıgın gibi yaşarsın</p>
										<h5 class="mu-rt-name">Mehmet Ürgün</h5>
										<span class="mu-rt-title">Web Designer </span>
									</li>

								</ul>
							</div>

						</div>
					</div>
				</div>
			</div>
		</section>